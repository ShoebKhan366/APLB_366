
interface Testable {
    void display(); 
}
