public class IndianCrow implements Crow{
    public void cry(){
        System.out.println("crawing");
    }
    public void fly(){
        System.out.println("high in sky");
    }
    public void eat(){
        System.out.println("eating pearls");
    }
}