class Whisky extends Beverage{
    protected void addCondiment(){
        System.out.println("Add ice");
    }
    protected void Stir(){
        System.out.println("Stir for 30 seconds");
    }
}