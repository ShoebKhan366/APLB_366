class Child extends Mother{
    void show(){
        System.out.println("they are children");
    }
    
}