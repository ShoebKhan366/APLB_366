class Mother{
    int age;
    int name;
    void show(){
        System.out.println("She is his mother");
    }
}