public interface Crow{
    public void fly();
     public void cry();
     public void eat();
    

}