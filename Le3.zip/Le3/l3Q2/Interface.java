interface Testable{
    void display();
}