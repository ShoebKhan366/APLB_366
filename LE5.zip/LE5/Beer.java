class Beer extends Beverage{
    protected void addCondiment(){
        System.out.println("Nothing");
    }
}