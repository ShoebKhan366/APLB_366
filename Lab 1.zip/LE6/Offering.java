abstract class Offering{
    abstract int getPrice();
    abstract String getName();

}