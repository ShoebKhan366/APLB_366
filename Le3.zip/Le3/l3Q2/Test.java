
class Test implements Testable{
    public void display(){
        System.out.println("class test implements testable interface");
    }
}

