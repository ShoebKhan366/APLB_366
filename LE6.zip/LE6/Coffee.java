class Coffee extends Offering{
    int getPrice(){
        return 30;
    }
    String getName(){
        return "Coffee";
    }
}