class Tea extends Offering{
    int getPrice(){
        return 25;
    }
    String getName(){
        return "Tea";
    }
}