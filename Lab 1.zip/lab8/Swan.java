public interface Swan{
    public void swim();
     public void sing();
     public void eat();
    

}